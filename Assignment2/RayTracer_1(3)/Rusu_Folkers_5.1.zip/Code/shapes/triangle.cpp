#include "triangle.h"
#include <tgmath.h>

/* The source basic concepts and general algorithm:
 https://www.scratchapixel.com/lessons/3d-basic-rendering/ray-tracing-rendering-a-triangle/ray-triangle-intersection-geometric-solution
 */

Hit Triangle::intersect(Ray const &ray)
{
    double Eps = 0.0000001;

    /* Check the case when the plane that contains the 
    triangle is parallel to the ray (ray direction) */
    float perpendicularCoef = ray.D.dot(N);

    if(fabs(perpendicularCoef) < Eps)
        return Hit::NO_HIT();
    
    /* Calculate distance from the the origin (0,0,0) to the plane, 
    parallel to the plane's normal */
    float distance = -v0.dot(N);
    
    // Calculate the distance from ray origin to P (the hit point on the plane)
    float t = -(ray.O.dot(N) + distance) / perpendicularCoef;

    // Check for the case when triangle is behind the ray
    if(t < 0)
        return Hit::NO_HIT();
    
    // Calculate the intersection point
    Triple P = ray.O + t * ray.D;

    /* Check if the intersection point on the plane is inside the triangle,
    this is done by checking if P is on the left side of each edge*/
    Triple perpendicularToPlane;

    // Check edge 0
    Triple edgeZero = v1 - v0;
    // The distance from the P point to the vertex
    Triple pToVertexZero = P - v0;
    /* The dot product between the trangle's normal and perpendicularToPlane 
    vector should be possitive if P is inside the triangle (inside-outside test)*/
    perpendicularToPlane = edgeZero.cross(pToVertexZero);
    if(perpendicularToPlane.dot(N) < 0)
        return Hit::NO_HIT();
    
    // check edge 1
    Triple edgeOne = v2 - v1;
    Triple pToVertexOne = P - v1;
    perpendicularToPlane = edgeOne.cross(pToVertexOne);
    if(perpendicularToPlane.dot(N) < 0)
        return Hit::NO_HIT();

    // check edge 2
    Triple edgeTwo = v0 - v2;
    Triple pToVertexTwo = P - v2;
    perpendicularToPlane = edgeTwo.cross(pToVertexTwo);
    if(perpendicularToPlane.dot(N) < 0)
        return Hit::NO_HIT();

    return Hit(t, N);
}

Triangle::Triangle(Point const &v0,
                   Point const &v1,
                   Point const &v2)
:
    v0(v0),
    v1(v1),
    v2(v2),
    N()
{
    // Calculate the surface normal here and store it in the N,
    // which is declared in the header. It can then be used in the intersect function.
    N = (v1 - v0).cross(v2 - v0); 
    N.normalize();
}
